#' Read GMT. FILE
#'
#' HGNC provides gene familes, we have curtaed them to gene sets used for GSEA, this package simply loads a gmt file used in R shiny
#'
#' @docType package
#'
#' @author Hunter Eby \email {huntereby66@gmial.com}
#'
#' @name GMT.File.HGNC
NULL

