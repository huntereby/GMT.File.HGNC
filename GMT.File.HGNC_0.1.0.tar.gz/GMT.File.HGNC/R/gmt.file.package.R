#'Read GMT. FILE
#'
#'Provides user with HGNC Mouse_hgnc2.gmt File for fgsea use
#'
#'
#'@export

library("fgsea")
library("devtools")
library("roxygen2")

GMT.FILE <- gmtPathways("Data/Mouse_hgnc2.gmt")

